rm -rf /code/VCPFrontend/build/
npm install --prefix /code/VCPFrontend
npm run build --prefix /code/VCPFrontend