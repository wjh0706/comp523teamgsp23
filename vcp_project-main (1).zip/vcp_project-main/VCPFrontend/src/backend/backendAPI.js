const TESTHOST = 'http://vcptest-env.eba-7spnf825.us-east-1.elasticbeanstalk.com'
// const TESTHOST = 'http://localhost:8000'
export default TESTHOST