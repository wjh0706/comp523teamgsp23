DATABASE_SETTING = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'vcptest2',
        'USER': 'teamz',
        'PASSWORD': 'teamz2021',
        'HOST': 'vcptest2.cglxxq8uwdnr.us-east-1.rds.amazonaws.com',
        'PORT': 5432,
    }
}