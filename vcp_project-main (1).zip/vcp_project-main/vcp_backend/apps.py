from django.apps import AppConfig


class VcpConfig(AppConfig):
    name = 'vcp_backend'
